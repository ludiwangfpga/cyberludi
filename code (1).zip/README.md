roslaunch motor_moveit_config gazebo.launch 

rosrun motor_move motor_move.py
