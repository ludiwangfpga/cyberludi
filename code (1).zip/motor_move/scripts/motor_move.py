#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import rospy
import moveit_commander
from moveit_msgs.msg import RobotTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint

class JointMover:
    def __init__(self, group_name):
        # 初始化 moveit_commander 和 rospy
        moveit_commander.roscpp_initialize(sys.argv)
        rospy.init_node('move_joint_node', anonymous=True)

        # 获取 robot 和 scene 的接口
        self.robot = moveit_commander.RobotCommander()
        self.scene = moveit_commander.PlanningSceneInterface()

        # 获取 planning group 的接口
        self.group = moveit_commander.MoveGroupCommander(group_name)

    def move_joint(self, delta_angle):
        # 获取当前关节角度
        current_angle = self.group.get_current_joint_values()[0]  # 该值为弧度

        # 将增量角度转换为弧度，并与当前角度相加
        target_angle = current_angle + delta_angle * 3.14 / 180  # 增加的角度需要转换为弧度

        # 设置关节的目标角度
        self.group.set_joint_value_target([target_angle])

        # 规划并执行路径
        plan = self.group.plan()
        self.group.execute(plan, wait=True)

        # 确保没有剩余的路径在执行
        self.group.stop()
        self.group.clear_pose_targets()

    def shutdown(self):
        # 退出 MoveIt
        moveit_commander.roscpp_shutdown()


if __name__ == "__main__":
    # 创建 JointMover 对象
    mover = JointMover("bearing")

    while True:
        # 从终端读取用户输入的角度并转换为浮点数
        try:
            delta_angle = float(raw_input("请输入要移动的角度 (ctrl+z退出): "))  
        except ValueError:
            print("输入无效。请输入一个数值或退出。")
            continue

        # 移动相应的度数
        mover.move_joint(delta_angle)
